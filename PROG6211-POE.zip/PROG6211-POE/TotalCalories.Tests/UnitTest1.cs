using MoilaGumaniPart2;

namespace TotalCalories.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void TotalCaloriesTest()
        {
            List<int> caloriesTest = new List<int>();
            caloriesTest.Add(200);
            caloriesTest.Add(100);

            if (Ingredient.getTotCalories(caloriesTest) != 300)
                throw new Exception();

           
        }
    }
}