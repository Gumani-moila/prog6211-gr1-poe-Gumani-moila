﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Microsoft.VisualBasic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace PROG6211_POE
{
    public delegate void CaloriesNotification(int calories, string message);
    public partial class Form1 : Form
    {

        static void CaloriesMessage(int calories, string text) => MessageBox.Show(text.ToUpper()+" " + calories, "Calories",MessageBoxButtons.OK, MessageBoxIcon.Warning);

        //global variables
        static List<Ingredient> myIngredient = new List<Ingredient>(); //declaration of generics list collection
        static List<Step> myStep = new List<Step>();
        static List<int> myCalories = new List<int>();
        static List<Recipe> myRecipe = new List<Recipe>();
        static List<string> recipesNames = new List<string>();
        //variables and initializing them to a default value;
        static int numIngredient = 0;
        static string ingredientName = "";
        static double scaleFactor = 0;
        static int caloriesNum = 0;
        static char foodGroup;
        static double ingredientQuantity = 0;
        static string unitMeasurement = "";
        static int numStep = 0;
        static string stepDescription = "";
        static Form form1 = new Form1();

        static void displayRecipe()
        {
            Program.form1.lstbx1.Items.Clear();
            Program.form1.lstbx1.Items.Add("Your Recipe Name List");
            Program.form1.lstbx1.Items.Add("__________________________________________");
            var sortedRecipList = myRecipe.OrderBy(p => p.GetRecipeName());

            foreach (var item in sortedRecipList)
            { 
             
                
                string value = "Your recipe name is  : " + item.GetRecipeName();
                Program.form1.lstbx1.Items.Add(value);
            }

        }
        static void searchRecipeByName(string name)
        {
            Program.form1.lstbx1.Items.Clear();
            foreach (Recipe item in myRecipe)
            {
                if (item.GetRecipeName().Equals(name))
                {
                    Program.form1.lstbx1.Items.Add("Your recipe name that you have request : "+ item.GetRecipeName());
                }
            }
        }
        static void searchByFoodGrp(char foodGrp)
        {
            Program.form1.lstbx1.Items.Clear();
            foreach (Ingredient item in myIngredient)
            {
                if (item.GetFoodGroup().Equals(foodGrp))
                {
                    Program.form1.lstbx1.Items.Add("Your Ingredient name that you have request : " + item.GetIngredientName());
                    Program.form1.lstbx1.Items.Add("Ingredient quantity : " + item.GetIngredientQuantity());
                    Program.form1.lstbx1.Items.Add("Ingredient unit of measurement : " + item.GetUnitMeasurement());
                    Program.form1.lstbx1.Items.Add("Ingredient number of calories : " + item.GetCaloriesNum());
                    Program.form1.lstbx1.Items.Add("Ingredient food group : " + item.GetFoodGroup());
                }
            }
        }
        static void searchByMaxCalories(int maxValue)
        {
            Program.form1.lstbx1.Items.Clear();
            foreach (Ingredient item in myIngredient)
            {
                if (item.GetCaloriesNum() <= maxValue)
                {
                    Program.form1.lstbx1.Items.Add("Your Ingredient name that you have request : " + item.GetIngredientName());
                    Program.form1.lstbx1.Items.Add("Ingredient quantity : " + item.GetIngredientQuantity());
                    Program.form1.lstbx1.Items.Add("Ingredient unit of measurement : " + item.GetUnitMeasurement());
                    Program.form1.lstbx1.Items.Add("Ingredient number of calories : " + item.GetCaloriesNum());
                    Program.form1.lstbx1.Items.Add("Ingredient food group : " + item.GetFoodGroup());
                }
            }
        }
        static void searchIngredientByName(string name)
        {
            Program.form1.lstbx1.Items.Clear();
            foreach (Ingredient item in myIngredient)
            {
                if (item.GetIngredientName().Equals(name))
                {
                    Program.form1.lstbx1.Items.Add("Your Ingredient name that you have request : " + item.GetIngredientName());
                    Program.form1.lstbx1.Items.Add("Ingredient quantity : " + item.GetIngredientQuantity());
                    Program.form1.lstbx1.Items.Add("Ingredient unit of measurement : " + item.GetUnitMeasurement());
                    Program.form1.lstbx1.Items.Add("Ingredient number of calories : " + item.GetCaloriesNum());
                    Program.form1.lstbx1.Items.Add("Ingredient food group : " + item.GetFoodGroup());
                }
            }
        }
        static void getRecipe()
        {

            string recipeName = Program.form1.recNameInpBox.Text;
            if (recipeName == "")
            {
                MessageBox.Show("Please fill the recipe name textbox", "Recipe Name Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            Recipe objRecipe = new Recipe(recipeName);
                myRecipe.Add(objRecipe);
                displayRecipe();
               
        }
        static void getIngAndSteps()
        {
            Ingredient objIngredient;
            numIngredient =int.Parse(Interaction.InputBox("Please enter the number of ingredient : ", "Ingredient")); 

            for (var i = 0; i < numIngredient; i++)
            {
                ingredientName = Interaction.InputBox("Please enter the name of the ingredient number : " + (i +1)+" ","Ingredient");
                ingredientQuantity = int.Parse (Interaction.InputBox("Please enter the quantity of ingredient number : " + (i + 1) + " ", "Ingredient"));
               unitMeasurement =  Interaction.InputBox("Please enter the unit of measurement of ingredient number : " + (i + 1) + " ", "Ingredient");
                caloriesNum = int.Parse(Interaction.InputBox("Enter the number of calories of your ingredient  : " + (i + 1) + " ", "Ingredient"));
                foodGroup= Convert.ToChar(Interaction.InputBox("Enter the food group of your ingredient  : " + (i + 1) + " ", "Ingredient"));
                //initializing the indgredient object with its values
                objIngredient = new Ingredient(ingredientName, ingredientQuantity, unitMeasurement, caloriesNum, foodGroup);
                myIngredient.Add(objIngredient);
                System.Windows.Forms.CheckBox chk = new System.Windows.Forms.CheckBox();
                chk.Width = 80;
                chk.Text = ingredientName;
                chk.CheckedChanged += new EventHandler(changecheck);
                Program.form1.flowPanel.Controls.Add(chk);
                

            }
            //inserting the calories in the arraylist
            foreach (Ingredient item in myIngredient)
            {
                myCalories.Add(item.GetCaloriesNum());
            }

            getStep();

        }

        private static void changecheck(object sender, EventArgs e)
        {
            System.Windows.Forms.CheckBox chk = sender as System.Windows.Forms.CheckBox;
            if (chk.Checked)
            {
              recipesNames.Add(chk.Text);
            }else if (chk.Checked == false)
            {
                recipesNames.IndexOf(chk.Text);
                int indexItem = recipesNames.IndexOf(chk.Text);
                recipesNames.RemoveAt(indexItem);
              
            }
        }

        static void getStep()
        {
           
           numStep = int.Parse(Interaction.InputBox("Enter the number of steps you want to store : "));
            for (int i = 0; i < numStep; i++)
            {
              stepDescription = Interaction.InputBox("Please enter the description of  step number : " + (i + 1) + " ", "Steps");
                //initializing the steps object with its values
                Step objStep = new Step(stepDescription);
                myStep.Add(objStep);
            }
        }
        static void displayIngredient()
        {
            Program.form1.lstbx1.Items.Clear();
            Program.form1.lstbx1.Items.Add("Your Ingredient list");
             Program.form1.lstbx1.Items.Add("====================================");
            //loop
            foreach (Ingredient item in myIngredient)
            {
                Program.form1.lstbx1.Items.Add("Ingredient name : " + item.GetIngredientName());
                Program.form1.lstbx1.Items.Add("Ingredient quantity : "+ item.GetIngredientQuantity());
                Program.form1.lstbx1.Items.Add("Ingredient unit of measurement : "+ item.GetUnitMeasurement());
                Program.form1.lstbx1.Items.Add("Ingredient number of calories : "+ item.GetCaloriesNum());
                Program.form1.lstbx1.Items.Add("Ingredient food group : "+ item.GetFoodGroup());
                Program.form1.lstbx1.Items.Add("");
            }
            int calories = Ingredient.getTotCalories(myCalories);
            if (calories > 300)
            {
                CaloriesNotification caloriesNotify = CaloriesMessage;
                caloriesNotify(calories, "Ingredient total calories execeeds 300 and your amount of calories is : ");

            }
            else
            {
                MessageBox.Show("Your total calories is : " + calories,"Total Calories",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
        static void displayStep()
        {
            Program.form1.lstbx1.Items.Add("Ingredient Steps");
            Program.form1.lstbx1.Items.Add("_________________________________");
            int countStep = 0;
            //loop
            foreach (Step item in myStep)
            {
                countStep = countStep + 1;
                Program.form1.lstbx1.Items.Add("Step number " + countStep +": "+ item.GetDescription());
            }
        }
            public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            getRecipe();
        }

        private void ingBtn_Click(object sender, EventArgs e)
        {
            getIngAndSteps();
            displayIngredient();
            displayStep();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           if (scaleFactor == 0)
            {
                int scaleFactorMenu = int.Parse(Interaction.InputBox("Select the following scale factor options of your ingredient : 1 = 0.5(half), 2 = 2(double) or 3 = 3(tripple)", "Ingredient Search"));
                //validating the enter menu choice value if is true the assign a specific scale factor
                if (scaleFactorMenu == 1)
                {
                    scaleFactor = 0.5;
                }
                if (scaleFactorMenu == 2)
                {
                    scaleFactor = 2;
                }
                if (scaleFactorMenu == 3)
                {
                    scaleFactor = 3;
                }
                foreach (Ingredient item in myIngredient)
                {
                    double quantity = scaleFactor * item.GetIngredientQuantity();
                    item.SetIngredientQuantity(quantity);

                }
                Program.form1.btnScale.Text = "Reset Ingredient Scale";
                displayIngredient();

            }
            else
            {
                foreach (Ingredient item in myIngredient)
                {
                    double quantity = item.GetIngredientQuantity() / scaleFactor;
                    item.SetIngredientQuantity(quantity);

                }
                Program.form1.btnScale.Text = "Add Ingredient Scale";
                displayIngredient();
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           int comboBxIndex = comboBox1.SelectedIndex;
          if(comboBxIndex == 0)
            {
                string name = Interaction.InputBox("Enter the Ingredient name you want to retrieve", "Ingredient Search");
                searchIngredientByName(name);

            }else if(comboBxIndex == 1) {
                char foodGrp = Convert.ToChar(Interaction.InputBox("Enter the Ingredient food group  you want to retrieve", "Ingredient Search"));
                searchByFoodGrp(foodGrp);

            }
            else if(comboBxIndex == 2)
            {
                int maxValue =int.Parse(Interaction.InputBox("Enter the Ingredient maximum calories you want to retrieve", "Ingredient Search"));
                searchByMaxCalories(maxValue);

            }
            else
            {
                string name = Interaction.InputBox("Enter the Recipe name you want to retrieve", "Ingredient Search");
                searchRecipeByName(name);

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            recipeChart.Visible = false;
          
        }

        private void btnPie_Click(object sender, EventArgs e)
        {
            if (recipesNames.Count == 0)
            {
                MessageBox.Show("Recipes not found ", "Recipe Pie Chart",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            foreach (var series in recipeChart.Series)
            {
              
                series.Points.Clear();
            }
            recipeChart.Visible = true;
            if (!recipeChart.Titles.Equals("Recipe food group percentage") )
            {
                recipeChart.Titles.Add("Recipe food group percentage");
            }
            recipeChart.Series["s1"].IsValueShownAsLabel = true;
            foreach (var item in recipesNames)
            {
                foreach (Ingredient value in myIngredient)
                {
                    if (item.Equals(value.GetIngredientName())) {
                        recipeChart.Series["s1"].Points.AddXY(value.GetFoodGroup(),value.GetCaloriesNum());
                      //  recipeChart.Series["s1"].Points.AddXY("2", "24");
                      //  recipeChart.Series["s1"].Points.AddXY("3", "203");
                       // recipeChart.Series["s1"].Points.AddXY("4", "100");
                    }
                }
             }
        }
    }
}
