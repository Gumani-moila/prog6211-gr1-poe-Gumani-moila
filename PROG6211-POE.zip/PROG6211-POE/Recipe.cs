﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6211_POE
{
    internal class Recipe
    {
        private string recipeName;

        public Recipe(string recipeName)
        {
            this.recipeName = recipeName;
        }

        public string GetRecipeName()
        {
            return recipeName;
        }
        public void SetRecipeName(string recipeName)
        {
            this.recipeName = recipeName;
        }
    }
}
