﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6211_POE
{
    internal class Ingredient
    {
            private string ingredientName = "";
            private double ingredientQuantity = 0;
            private string unitMeasurement = "";
            private int caloriesNum = 0;
            private char foodGroup;
            public Ingredient()
            {

            }
            public Ingredient(string ingredientName, double ingredientQuantity, string unitMeasurement, int caloriesNum, char foodGroup)
            {
                this.ingredientName = ingredientName;
                this.ingredientQuantity = ingredientQuantity;
                this.unitMeasurement = unitMeasurement;
                this.caloriesNum = caloriesNum;
                this.foodGroup = foodGroup;

            }
            //get and setters for the indegrient class
            public string GetIngredientName()
            {
                return ingredientName;
            }
            public void SetIngredientName(string ingredientName)
            {
                this.ingredientName = ingredientName;
            }
            public double GetIngredientQuantity()
            {
                return ingredientQuantity;
            }
            public void SetIngredientQuantity(double ingredientQuantity)
            {
                this.ingredientQuantity = ingredientQuantity;
            }
            public int GetCaloriesNum()
            {
                return caloriesNum;
            }
            public void SetCaloriesNum(int caloriesNum)
            {
                this.caloriesNum = caloriesNum;
            }
            public char GetFoodGroup()
            {
                return foodGroup;
            }
            public void SetFoodGroup(char foodGroup)
            {
                this.foodGroup = foodGroup;
            }
            public string GetUnitMeasurement()
            {
                return unitMeasurement;
            }
            public void SetUnitMeasurement(string unitMeasurement)
            {
                this.unitMeasurement = unitMeasurement;
            }

            public static int getTotCalories(List<int> myCalories)
            {
                int total = 0;
                foreach (var item in myCalories)
                {
                    total += item;
                }
                return total;
            }
        
    }
}
